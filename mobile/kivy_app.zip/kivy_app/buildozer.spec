[app]

# (str) Title of your application
title = offRez

# (str) Package name
package.name = offrez

# (str) Package domain (needed for android/ios packaging)
package.domain = com.stayrez

# (str) Source code where the main.py live
source.dir = .

# (list) Source files to include (let empty to include all the files)
source.include_exts = py,png,jpg,kv,atlas,json

# (list) List of exclusions using pattern matching
#source.exclude_exts = spec,kv.orig,custom.py

# (list) List of directory to exclude (let empty to not exclude everything)
#source.exclude_dirs = tests, bin, venv

# (list) List of exclusions using pattern matching
# Do not include the private keys or secrets
#source.exclude_patterns = license,images/*/*.jpg

# (str) Application versioning (method 1)
version = 0.1

# (list) Application requirements
# comma separated e.g. requirements = sqlite3,kivy
requirements = python3,kivy,pillow,certifi,openssl

# (str) Custom source folders for requirements
# Sets custom source for any requirements with recipes
# requirements.source.kivy = ../../kivy

# (list) Garden requirements
#garden_requirements = 

# (str) Presplash of the application
presplash.filename = %(source.dir)s/assets/offrez_logo.png

# (str) Icon of the application
icon.filename = %(source.dir)s/assets/offrez_logo.png

# (str) Supported orientation (one of landscape, sensorLandscape, portrait or all)
orientation = portrait

# (bool) Indicate if the application should be fullscreen or not
fullscreen = 0

# (list) Permissions
android.permissions = INTERNET

# (int) Target Android API, should be as high as possible (usually latest official)
android.api = 33

# (int) Minimum API your APK will support.
android.minapi = 21

# (int) Android SDK version to use
#android.sdk = 20

# (str) Android NDK version to use
#android.ndk = 19b

# (bool) Use --private data storage (True) or --dir public storage (False)
#android.private_storage = True

# (str) Android entry point, default is ok for Kivy-based app
#android.entrypoint = org.kivy.android.PythonActivity

# (list) Pattern to exclude from the final apk
#android.skip_update_options = path/to/exclude1

# (bool) If True, then skip trying to update the Android sdk
# This can be useful to avoid excess Internet downloads or save time
# when an update is due and you just want to test/build your package
# android.skip_update = False

# (bool) If True, then automatically accept SDK license
# agreements. This is intended for automation only. If set to False,
# the default, you will be shown the license when first running
# buildozer.
android.accept_sdk_license = True

# (str) Android logcat filters to use
#android.logcat_filters = *:S python:D

# (str) Android additional libraries to copy into libs/armeabi
#android.add_libs_armeabi = libs/android/*.so
#android.add_libs_armeabi_v7a = libs/android-v7/*.so
#android.add_libs_arm64_v8a = libs/android-v8/*.so
#android.add_libs_x86 = libs/android-x86/*.so
#android.add_libs_mips = libs/android-mips/*.so

# (bool) Copy library instead of making a libpymodules.so
#android.copy_libs = 1

# (list) The Android archs to build for, choices: armeabi-v7a, arm64-v8a, x86, x86_64
android.archs = arm64-v8a, armeabi-v7a

# (bool) enables Android auto backup feature (Android API >=23)
android.allow_backup = True

# (str) XML file for manifest extras
#android.manifest_extras = %(source.dir)s/android_manifest_extras.xml

# (list) Android AAR archives to add
#android.add_aars =

# (list) Gradle dependencies to add
#android.gradle_dependencies =

# (bool) Enable AndroidX support. Enable when 'android.gradle_dependencies'
# contains an 'androidx' package, or any package from Kotlin source.
# android.enable_androidx = False

# (list) Java files to add
#android.add_src =

# (list) Java/Kotlin JAR files to add
#android.add_jars =

# (list) List of Java files to add to the android project (can be java or a
# directory containing the files)
#android.add_src =

# (list) Gradle repositories to add {can be necessary for some android.gradle_dependencies}
# please enclose in double quotes 
#android.add_gradle_repositories =

# (list) Packaging options to add 
# see https://google.github.io/android-gradle-dsl/current/com.android.build.gradle.internal.dsl.PackagingOptions.html
# can be necessary to solve conflicts in gradle_dependencies
# please enclose in double quotes 
#android.packaging_options =

# (list) Java classes to add as activities to the manifest 
#android.add_activities =

# (str) OUYA Console category. Should be one of GAME or APP
# The default is GAME, but it is unlikely that is what you want.
#android.ouya.category = GAME

# (str) Filename of OUYA Console icon. It must be a 732x412 png image.
#android.ouya.icon.filename = %(source.dir)s/data/ouya_icon.png

# (str) XML file for the manifest <application> tag. This can be used to add
# custom metadata or other attributes to the application tag.
#android.manifest.application_extras = %(source.dir)s/android_manifest_application_extras.xml

# (list) Android additional libraries to copy into libs/armeabi
#android.add_libs_armeabi = libs/android/*.so
#android.add_libs_armeabi_v7a = libs/android-v7/*.so
#android.add_libs_arm64_v8a = libs/android-v8/*.so
#android.add_libs_x86 = libs/android-x86/*.so
#android.add_libs_mips = libs/android-mips/*.so

# (bool) Indicate whether the screen should stay on
# Don't forget to add the WAKE_LOCK permission if you set this to True
#android.wakelock = False

# (list) Android application meta-data to set (key=value format)
#android.meta_data =

# (list) Android library project to add (will be added in the
# project.properties automatically.)
#android.library_references =

# (str) Android logcat filters to use
#android.logcat_filters = *:S python:D

# (str) Android additional adb arguments
#android.adb_args = -H host.docker.internal

# (str) Python for android branch to use, if not master, useful to test
# a specific branch
#p4a.branch = master

# (str) Python for android repository to use, if not master, useful to test
# a specific repository
#p4a.source_dir =

# (str) The directory in which python-for-android should look for your own build recipes (if any)
#p4a.local_recipes =

# (str) Filename to the hook for p4a
#p4a.hook =

# (str) Bootstrap to use for android builds
# p4a.bootstrap = sdl2

# (int) port number to specify an explicit --port number to p4a with.
# p4a.port = 

# (str) Control the orientation of the screen
# orientation = portrait

# (list) List of service to declare
#services = NAME:ENTRYPOINT_TO_PY,NAME2:ENTRYPOINT2_TO_PY

#
# iOS specific
#

# (str) Name of the application
ios.title = offRez

# (str) iTunes Connect Bundle ID
ios.bundle_identifier = com.stayrez.offrez

# (str) Bundle Identifier
ios.bundle_name = offrez

# (list) Source files to include (let empty to include all the files)
ios.source.include_exts = py,png,jpg,kv,atlas,json

# (list) List of exclusions using pattern matching
#ios.source.exclude_exts = spec,kv.orig,custom.py

# (list) List of directory to exclude (let empty to not exclude everything)
#ios.source.exclude_dirs = tests, bin, venv

# (list) List of exclusions using pattern matching
#ios.source.exclude_patterns = license,images/*/*.jpg

# (str) Name of the python usage in the Xcode project
#ios.python_usage = Python

# (bool) Use the custom storyboard
#ios.use_custom_storyboard = False

# (str) Path to the custom storyboard
#ios.storyboard = %(source.dir)s/data/main.storyboard

# (list) List of modules to compile
#ios.compile_modules = 

# (list) List of frameworks to link
#ios.link_frameworks = 

# (list) List of frameworks to embed
#ios.embed_frameworks = 

# (list) List of libraries to link
#ios.link_libraries = 

# (list) List of resources to copy
#ios.copy_resources = 

# (list) List of frameworks to weak link
#ios.weak_link_frameworks = 

# (list) List of system frameworks to weak link
#ios.weak_link_system_frameworks = 

# (list) List of extra plist
#ios.plist_extras = 

# (list) List of extra xcode build settings
#ios.xcode_build_settings = 

# (list) List of extra xcode build phases
#ios.xcode_build_phases = 

[buildozer]

# (int) Log level (0 = error only, 1 = info, 2 = debug (with command output))
log_level = 2

# (int) Display warning if buildozer is run as root (0 = False, 1 = True)
warn_on_root = 1

# (str) Path to build artifact storage, absolute or relative to spec file
# build_dir = ./.buildozer

# (str) Path to build output (i.e. .apk, .aab, .ipa) storage
# bin_dir = ./bin
